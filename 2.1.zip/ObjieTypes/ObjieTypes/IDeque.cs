﻿using System;

using System.Collections.Generic;

namespace ObjieTypes
{
    public interface IDeque<T> : IList<T>
    {
        void AddFirst(T item);
        bool RemoveFirst();
    }
}
