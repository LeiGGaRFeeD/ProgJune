﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Deque<int> deque = new Deque<int>();

        deque.Add(1);
        deque.AddFirst(2);
        deque.Add(3);

        Console.WriteLine("Дек содержит:");
        foreach (var item in deque)
        {
            Console.WriteLine(item);
        }

        deque.RemoveFirst();
        Console.WriteLine("После удаления первого элемента:");
        foreach (var item in deque)
        {
            Console.WriteLine(item);
        }

        //Задание 2
        Console.WriteLine();
        Console.WriteLine("Задание 2");
        int number1 = Convert.ToInt32(Console.ReadLine());
        int number2 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine($"До замены: number1 = {number1}, number2 = {number2}");

        Swaper.SwapValues(ref number1, ref number2);

        Console.WriteLine($"После замены: number1 = {number2}, number2 = {number1}");
    }
    public static class Swaper
    {
        public static void SwapValues<T>(ref T value1, ref T value2)
        {
            T temp = value1;
            value1 = value2;
            value2 = temp;
        }
    }
}
