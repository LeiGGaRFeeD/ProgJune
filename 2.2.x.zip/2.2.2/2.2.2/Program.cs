﻿using System;
using System.Collections.Generic;

public delegate void ProcessElement<T>(T element);

public static class ListProcessor
{
    public static void ProcessList<T>(List<T> list, ProcessElement<T> processElement)
    {
        foreach (var item in list)
        {
            processElement(item);
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Пример списка целых чисел
        List<int> intList = new List<int> { 1, 2, 3, 4, 5 };

        // Пример использования метода обработки, который выводит элементы на консоль
        ListProcessor.ProcessList(intList, PrintInt);

        // Пример списка строк
        List<string> stringList = new List<string> { "apple", "banana", "cherry" };

        // Пример использования метода обработки, который выводит элементы на консоль
        ListProcessor.ProcessList(stringList, PrintString);
    }

    static void PrintInt(int value)
    {
        Console.WriteLine($"Int value: {value}");
    }

    static void PrintString(string value)
    {
        Console.WriteLine($"String value: {value}");
    }
}
