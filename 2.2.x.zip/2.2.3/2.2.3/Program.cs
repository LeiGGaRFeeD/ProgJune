﻿using System;
using System.Collections.Generic;
using System.Linq;

public static class ListProcessor
{
    // Обобщенный метод, который принимает список элементов типа T и делегат Func<T, TResult>
    public static List<TResult> ProcessList<T, TResult>(List<T> list, Func<T, TResult> func)
    {
        List<TResult> resultList = new List<TResult>();
        foreach (var item in list)
        {
            resultList.Add(func(item));
        }
        return resultList;
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Пример списка целых чисел
        List<int> intList = new List<int> { 1, 2, 3, 4, 5 };

        // Пример использования метода обработки, который возводит элементы в квадрат
        List<int> squaredList = ListProcessor.ProcessList(intList, Square);

        Console.WriteLine("Squared integers:");
        squaredList.ForEach(Console.WriteLine);

        // Пример списка строк
        List<string> stringList = new List<string> { "apple", "banana", "cherry" };

        // Пример использования метода обработки, который получает длину строки
        List<int> lengthList = ListProcessor.ProcessList(stringList, GetLength);

        Console.WriteLine("String lengths:");
        lengthList.ForEach(Console.WriteLine);
    }

    // Функция для возведения числа в квадрат
    static int Square(int value)
    {
        return value * value;
    }

    // Функция для получения длины строки
    static int GetLength(string value)
    {
        return value.Length;
    }
}
