﻿using System;
using System.Collections.Generic;

public static class ListProcessor
{
    // Обобщенный метод для фильтрации списка
    public static List<T> FilterList<T>(List<T> list, Predicate<T> predicate)
    {
        List<T> filteredList = new List<T>();
        foreach (var item in list)
        {
            if (predicate(item))
            {
                filteredList.Add(item);
            }
        }
        return filteredList;
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Запрос пользователя на ввод списка целых чисел
        List<int> intList = GetUserInput<int>("Enter integers (press Enter after each number, leave empty to finish): ");

        // Пример использования метода фильтрации для четных чисел
        List<int> evenNumbers = ListProcessor.FilterList(intList, IsEven);

        Console.WriteLine("Even numbers:");
        foreach (var number in evenNumbers)
        {
            Console.WriteLine(number);
        }

        // Запрос пользователя на ввод списка строк
        List<string> stringList = GetUserInput<string>("Enter strings (press Enter after each string, leave empty to finish): ");

        // Пример использования метода фильтрации для строк, начинающихся с буквы "a"
        List<string> startsWithA = ListProcessor.FilterList(stringList, StartsWithA);

        Console.WriteLine("Strings starting with 'a':");
        foreach (var str in startsWithA)
        {
            Console.WriteLine(str);
        }
    }

    // Функция для определения, является ли число четным
    static bool IsEven(int number)
    {
        return number % 2 == 0;
    }

    // Функция для определения, начинается ли строка с буквы "a" (регистронезависимо)
    static bool StartsWithA(string str)
    {
        return str.StartsWith("a", StringComparison.OrdinalIgnoreCase);
    }

    // Обобщенный метод для запроса ввода пользователем списка значений заданного типа
    static List<T> GetUserInput<T>(string prompt)
    {
        Console.WriteLine(prompt);
        List<T> inputList = new List<T>();
        while (true)
        {
            string userInput = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userInput))
            {
                break;
            }
            try
            {
                inputList.Add((T)Convert.ChangeType(userInput, typeof(T)));
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input! Please enter a valid value of type " + typeof(T).Name + ".");
            }
            catch (InvalidCastException)
            {
                Console.WriteLine("Invalid input! Please enter a valid value of type " + typeof(T).Name + ".");
            }
        }
        return inputList;
    }
}
