﻿using System;
using System.Collections.Generic;

public static class ListProcessor
{
    // Обобщенный метод для слияния двух списков
    public static List<T> MergeLists<T>(List<T> list1, List<T> list2, Func<T, T, T> mergeFunction)
    {
        List<T> mergedList = new List<T>();

        // Предполагаем, что оба списка имеют одинаковую длину
        int minLength = Math.Min(list1.Count, list2.Count);
        for (int i = 0; i < minLength; i++)
        {
            mergedList.Add(mergeFunction(list1[i], list2[i]));
        }

        // Добавляем оставшиеся элементы, если один список длиннее другого
        for (int i = minLength; i < list1.Count; i++)
        {
            mergedList.Add(list1[i]);
        }
        for (int i = minLength; i < list2.Count; i++)
        {
            mergedList.Add(list2[i]);
        }

        return mergedList;
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Пример списка целых чисел
        List<int> intList1 = new List<int> { 1, 2, 3 };
        List<int> intList2 = new List<int> { 4, 5, 6, 7 };

        // Пример использования метода слияния для списков целых чисел с операцией сложения
        List<int> mergedIntList = ListProcessor.MergeLists(intList1, intList2, (x, y) => x + y);

        Console.WriteLine("Merged integers:");
        foreach (var number in mergedIntList)
        {
            Console.WriteLine(number);
        }

        // Пример списка строк
        List<string> stringList1 = new List<string> { "apple", "banana", "cherry" };
        List<string> stringList2 = new List<string> { "date", "elderberry", "fig", "grape" };

        // Пример использования метода слияния для списков строк с операцией конкатенации
        List<string> mergedStringList = ListProcessor.MergeLists(stringList1, stringList2, (x, y) => x + "-" + y);

        Console.WriteLine("Merged strings:");
        foreach (var str in mergedStringList)
        {
            Console.WriteLine(str);
        }
    }
}
