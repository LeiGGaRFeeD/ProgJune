﻿using System;
using System.Collections.Generic;

public static class ListProcessor
{
    // Обобщенный метод для сортировки списка
    public static void SortList<T>(List<T> list, Comparison<T> comparison)
    {
        if (list == null)
        {
            throw new ArgumentNullException(nameof(list), "List cannot be null.");
        }

        if (comparison == null)
        {
            throw new ArgumentNullException(nameof(comparison), "Comparison delegate cannot be null.");
        }

        list.Sort(comparison);
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Запрос пользователя на ввод списка целых чисел
        List<int> intList = GetUserInput<int>("Enter integers (press Enter after each number, leave empty to finish): ");

        // Пример использования метода сортировки для списка целых чисел
        ListProcessor.SortList(intList, (x, y) => x.CompareTo(y));

        Console.WriteLine("Sorted integers:");
        foreach (var number in intList)
        {
            Console.WriteLine(number);
        }

        // Запрос пользователя на ввод списка строк
        List<string> stringList = GetUserInput<string>("Enter strings (press Enter after each string, leave empty to finish): ");

        // Пример использования метода сортировки для списка строк
        ListProcessor.SortList(stringList, (x, y) => string.Compare(x, y));

        Console.WriteLine("Sorted strings:");
        foreach (var str in stringList)
        {
            Console.WriteLine(str);
        }
    }

    // Обобщенный метод для запроса ввода пользователем списка значений заданного типа
    static List<T> GetUserInput<T>(string prompt)
    {
        Console.WriteLine(prompt);
        List<T> inputList = new List<T>();
        while (true)
        {
            string userInput = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userInput))
            {
                break;
            }
            try
            {
                inputList.Add((T)Convert.ChangeType(userInput, typeof(T)));
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input! Please enter a valid value of type " + typeof(T).Name + ".");
            }
            catch (InvalidCastException)
            {
                Console.WriteLine("Invalid input! Please enter a valid value of type " + typeof(T).Name + ".");
            }
        }
        return inputList;
    }
}
