﻿using System;

public static class ArrayProcessor
{
    // Обобщенный метод для применения делегата к каждому элементу массива
    public static void ProcessArray<T>(T[] array, Action<T> action)
    {
        foreach (var item in array)
        {
            action(item);
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Запрос пользователя на ввод целых чисел для массива
        int[] intArray = GetUserInput<int>("Enter integers (press Enter after each number, leave empty to finish): ");

        // Пример использования метода для применения делегата к каждому элементу массива целых чисел
        ArrayProcessor.ProcessArray(intArray, x => Console.WriteLine(x * x));

        // Запрос пользователя на ввод строк для массива
        string[] stringArray = GetUserInput<string>("Enter strings (press Enter after each string, leave empty to finish): ");

        // Пример использования метода для применения делегата к каждому элементу массива строк
        ArrayProcessor.ProcessArray(stringArray, x => Console.WriteLine(x.ToUpper()));
    }

    // Обобщенный метод для запроса ввода пользователем элементов массива заданного типа
    static T[] GetUserInput<T>(string prompt)
    {
        Console.WriteLine(prompt);
        var inputList = new List<T>();
        while (true)
        {
            string userInput = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userInput))
            {
                break;
            }
            try
            {
                inputList.Add((T)Convert.ChangeType(userInput, typeof(T)));
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input! Please enter a valid value of type " + typeof(T).Name + ".");
            }
            catch (InvalidCastException)
            {
                Console.WriteLine("Invalid input! Please enter a valid value of type " + typeof(T).Name + ".");
            }
        }
        return inputList.ToArray();
    }
}
