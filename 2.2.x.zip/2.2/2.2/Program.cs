﻿using System;

// Определение исключения IncorrectOptionalAccessException
public class IncorrectOptionalAccessException : InvalidOperationException
{
    public IncorrectOptionalAccessException() : base("Attempted to access value of an empty Optional.") { }
}

public delegate void ProcessElement<T>(T element);

public static class ListProcessor
{
    public static void ProcessList<T>(List<T> list, ProcessElement<T> processElement)
    {
        foreach (var item in list)
        {
            processElement(item);
        }
    }
}


// Определение интерфейса IOptional<T>
public interface IOptional<T> where T : struct
{
    T Value { get; set; }
    void SetValue(T? value);
    T GetValueOrDefault();
    bool Empty { get; }
}

// Реализация класса Optional<T>
public class Optional<T> : IOptional<T> where T : struct
{
    private T? _value;

    public Optional()
    {
        _value = null;
    }

    public Optional(T value)
    {
        _value = value;
    }

    public T Value
    {
        get
        {
            if (_value.HasValue)
            {
                return _value.Value;
            }
            else
            {
                throw new IncorrectOptionalAccessException();
            }
        }
        set
        {
            _value = value;
        }
    }

    public void SetValue(T? value)
    {
        _value = value;
    }

    public T GetValueOrDefault()
    {
        return _value ?? default(T);
    }

    public bool Empty => !_value.HasValue;

    public override string ToString()
    {
        return _value.HasValue ? _value.Value.ToString() : "empty";
    }
}

// Реализация класса ExtendedOptional<T>
public class ExtendedOptional<T> : Optional<T> where T : struct
{
    public event Action<T> OnOptionalFilled;
    public event Action OnOptionalEmptied;

    public ExtendedOptional() : base() { }

    public ExtendedOptional(T value) : base(value)
    {
        OnOptionalFilled?.Invoke(value);
    }

    public new T Value
    {
        get => base.Value;
        set
        {
            if (value.Equals(null))
            {
                OnOptionalEmptied?.Invoke();
            }
            else
            {
                OnOptionalFilled?.Invoke(value);
            }
            base.Value = value;
        }
    }

    public new void SetValue(T? value)
    {
        if (value.HasValue)
        {
            OnOptionalFilled?.Invoke(value.Value);
        }
        else
        {
            OnOptionalEmptied?.Invoke();
        }
        base.SetValue(value);
    }
}

// Основная программа
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите количество создаваемых Optional объектов:");
        int count = int.Parse(Console.ReadLine());

        IOptional<int>[] optionals = new IOptional<int>[count];
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"Введите значение для Optional объекта {i + 1}:");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int value))
            {
                optionals[i] = new Optional<int>(value);
            }
            else
            {
                optionals[i] = new Optional<int>();
            }
        }

        ExtendedOptional<int> extendedOptional = new ExtendedOptional<int>();
        extendedOptional.OnOptionalFilled += OnOptionalFilledHandler;
        extendedOptional.OnOptionalEmptied += OnOptionalEmptiedHandler;

        foreach (var optional in optionals)
        {
            Console.WriteLine(optional.ToString());
        }

        extendedOptional.SetValue(42);
        extendedOptional.SetValue(null);
    }

    static void OnOptionalFilledHandler(int value)
    {
        Console.WriteLine($"Optional filled with value: {value}");
    }

    static void OnOptionalEmptiedHandler()
    {
        Console.WriteLine("Optional emptied");
    }
}
