﻿using System;
using System.Collections;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите элементы массива через пробел:");
        string[] elements = Console.ReadLine().Split(' ');

        var array = new CustomArray<string>();

        foreach (var element in elements)
        {
            array.Add(element);
        }

        Console.WriteLine("Вперед:");
        foreach (var item in array.GetForwardSequence())
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();

        Console.WriteLine("Назад:");
        foreach (var item in array.GetBackwardSequence())
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();
    }
}

class CustomArray<T> : IEnumerable<T>
{
    private T[] array;
    private int count;
    private int version;

    public CustomArray()
    {
        array = new T[0];
        count = 0;
        version = 0;
    }

    private void Resize(int newSize)
    {
        Array.Resize(ref array, newSize);
    }

    public void Add(T value)
    {
        Resize(count + 1);
        array[count++] = value;
        version++;
    }

    public void RemoveAt(int position)
    {
        if (position < 0 || position >= count)
            throw new IndexOutOfRangeException();

        for (int i = position; i < count - 1; i++)
        {
            array[i] = array[i + 1];
        }

        count--;
        version++;
    }

    public IEnumerator<T> GetEnumerator()
    {
        return ((IEnumerable<T>)array).GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return array.GetEnumerator();
    }

    public IEnumerable<T> GetForwardSequence()
    {
        int startingVersion = version;

        foreach (var item in array)
        {
            if (version != startingVersion)
                throw new InvalidOperationException("Array has changed.");

            yield return item;
        }
    }

    public IEnumerable<T> GetBackwardSequence()
    {
        int startingVersion = version;

        for (int i = count - 1; i >= 0; i--)
        {
            if (version != startingVersion)
                throw new InvalidOperationException("Array has changed.");

            yield return array[i];
        }
    }
}
