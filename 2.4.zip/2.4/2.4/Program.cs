﻿using System;
using System.Collections;
using System.Collections.Generic;

public class ElemetNotFoundException : Exception
{
    public ElemetNotFoundException(string message) : base(message) { }
}

public class TestKeyValuePairs<T1, T2>
{
    public T1 Key { get; }
    public T2 Value { get; }

    public TestKeyValuePairs(T1 key, T2 value)
    {
        Key = key;
        Value = value;
    }
}

public class TestDictionary<T1, T2> : IEnumerable<TestKeyValuePairs<T1, T2>>
{
    private List<TestKeyValuePairs<T1, T2>> dictionary = new List<TestKeyValuePairs<T1, T2>>();

    public void Add(T1 key, T2 value)
    {
        foreach (var pair in dictionary)
        {
            if (EqualityComparer<T1>.Default.Equals(pair.Key, key))
            {
                throw new Exception("Key already exists.");
            }
        }

        dictionary.Add(new TestKeyValuePairs<T1, T2>(key, value));
    }

    public void RemoveByKey(T1 key)
    {
        var pairToRemove = dictionary.Find(pair => EqualityComparer<T1>.Default.Equals(pair.Key, key));
        if (pairToRemove == null)
        {
            throw new ElemetNotFoundException("Element with specified key not found.");
        }
        dictionary.Remove(pairToRemove);
    }

    public void RemoveByValue(T2 value)
    {
        var pairToRemove = dictionary.Find(pair => EqualityComparer<T2>.Default.Equals(pair.Value, value));
        if (pairToRemove == null)
        {
            throw new ElemetNotFoundException("Element with specified value not found.");
        }
        dictionary.Remove(pairToRemove);
    }

    public TestKeyValuePairs<T1, T2> FindByKey(T1 key)
    {
        var pair = dictionary.Find(pair => EqualityComparer<T1>.Default.Equals(pair.Key, key));
        if (pair == null)
        {
            throw new ElemetNotFoundException("Element with specified key not found.");
        }
        return pair;
    }

    public TestKeyValuePairs<T1, T2> FindByValue(T2 value)
    {
        var pair = dictionary.Find(pair => EqualityComparer<T2>.Default.Equals(pair.Value, value));
        if (pair == null)
        {
            throw new ElemetNotFoundException("Element with specified value not found.");
        }
        return pair;
    }

    public IEnumerator<TestKeyValuePairs<T1, T2>> GetEnumerator()
    {
        return dictionary.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}

class Program
{
    static void Main(string[] args)
    {
        TestDictionary<int, string> testDict = new TestDictionary<int, string>();

        while (true)
        {
            Console.WriteLine("1. Add element");
            Console.WriteLine("2. Remove element by key");
            Console.WriteLine("3. Remove element by value");
            Console.WriteLine("4. Find element by key");
            Console.WriteLine("5. Find element by value");
            Console.WriteLine("6. Display all elements");
            Console.WriteLine("7. Exit");
            Console.WriteLine("Select an option:");

            string option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.WriteLine("Enter key:");
                    int key = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter value:");
                    string value = Console.ReadLine();
                    testDict.Add(key, value);
                    break;
                case "2":
                    Console.WriteLine("Enter key to remove:");
                    int keyToRemove = int.Parse(Console.ReadLine());
                    testDict.RemoveByKey(keyToRemove);
                    break;
                case "3":
                    Console.WriteLine("Enter value to remove:");
                    string valueToRemove = Console.ReadLine();
                    testDict.RemoveByValue(valueToRemove);
                    break;
                case "4":
                    Console.WriteLine("Enter key to find:");
                    int keyToFind = int.Parse(Console.ReadLine());
                    var foundByKey = testDict.FindByKey(keyToFind);
                    Console.WriteLine($"Value for key {keyToFind}: {foundByKey.Value}");
                    break;
                case "5":
                    Console.WriteLine("Enter value to find:");
                    string valueToFind = Console.ReadLine();
                    var foundByValue = testDict.FindByValue(valueToFind);
                    Console.WriteLine($"Key for value {valueToFind}: {foundByValue.Key}");
                    break;
                case "6":
                    Console.WriteLine("All elements:");
                    foreach (var pair in testDict)
                    {
                        Console.WriteLine($"Key: {pair.Key}, Value: {pair.Value}");
                    }
                    break;
                case "7":
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }
}
