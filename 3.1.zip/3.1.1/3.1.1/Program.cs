﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите количество слов для хранения в массиве:");
        int count = int.Parse(Console.ReadLine());

        Console.WriteLine($"Введите {count} строки для массива:");
        List<string> words = Console.ReadLine().Split(' ').Take(count).ToList();

        // Дозаполнение массива, если введено меньше слов, чем count
        while (words.Count < count)
        {
            words.Add("0");
        }

        Console.WriteLine("Элементы массива:");
        for (int i = 0; i < words.Count; i++)
        {
            Console.WriteLine($"Элемент [{i}]: {words[i]}");
        }

        Console.WriteLine("Введите минимальную длину элемента, который вы хотите найти:");
        int minLength = int.Parse(Console.ReadLine());

        // Ленивый запрос LINQ для поиска элементов с минимальной длиной
        var result = words.Where(word => word.Length >= minLength);

        Console.WriteLine($"Пункты с минимум {minLength} символами:");
        foreach (var item in result)
        {
            Console.WriteLine($"Предмет: {item}");
        }
    }
}
