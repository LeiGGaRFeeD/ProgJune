﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        List<char> items = new List<char>();

        Console.WriteLine("Введите элементы списка (нажмите Enter после каждого элемента, для завершения введите пустую строку):");
        string input;
        do
        {
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
            {
                items.Add(char.Parse(input));
            }
        } while (!string.IsNullOrWhiteSpace(input));

        Console.WriteLine("Вот список предметов:");
        PrintItems(items);

        Console.WriteLine("Введите элемент для удаления:");
        char itemToRemove = char.Parse(Console.ReadLine());

        // Проверка наличия элемента в списке перед удалением
        if (items.Contains(itemToRemove))
        {
            items.Remove(itemToRemove);
            Console.WriteLine($"Элемент '{itemToRemove}' удален из списка.");
        }
        else
        {
            Console.WriteLine($"Элемент '{itemToRemove}' не найден в списке.");
        }

        Console.WriteLine("Вот список после удаления элемента:");
        PrintItems(items);
    }

    static void PrintItems(List<char> items)
    {
        foreach (char item in items)
        {
            Console.WriteLine($"Char: {item}");
        }
    }
}
