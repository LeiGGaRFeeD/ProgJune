﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Запрашиваем у пользователя имена файлов
        Console.WriteLine("Введите имена файлов (разделите их запятой и нажмите Enter):");
        string input = Console.ReadLine();
        string[] files = input.Split(',');

        // Группировка файлов по расширениям
        var fileGroups = files.Select(file => file.Trim())
                             .GroupBy(file => Path.GetExtension(file).ToLower());

        Console.WriteLine("Вот группа расширений файлов:");
        foreach (var group in fileGroups)
        {
            Console.WriteLine($"{group.Count()} файл (ов) с расширением {group.Key}");
        }
    }
}
