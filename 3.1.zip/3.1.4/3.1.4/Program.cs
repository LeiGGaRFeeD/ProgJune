﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите количество строк для хранения в массиве:");
        int count = int.Parse(Console.ReadLine());

        Console.WriteLine($"Введите {count} строки для массива:");
        string[] words = Console.ReadLine().Split(' ');

        // Дозаполнение массива, если введено меньше слов, чем count
        words = words.Concat(Enumerable.Repeat("0", Math.Max(0, count - words.Length))).ToArray();

        Console.WriteLine("Вот строка ниже, созданная с элементами вышеупомянутого массива:");
        string result = string.Join(", ", words);
        Console.WriteLine(result);
    }
}
