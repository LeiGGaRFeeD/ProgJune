﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите строку:");
        string input = Console.ReadLine();

        string[] words = input.Split(' ');

        // Используем LINQ для фильтрации слов в верхнем регистре
        var upperCaseWords = words.Where(word => !string.IsNullOrWhiteSpace(word) && word == word.ToUpper());

        Console.WriteLine("Upper-case слова:");
        foreach (var word in upperCaseWords)
        {
            Console.WriteLine(word);
        }
    }
}
