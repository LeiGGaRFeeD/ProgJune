﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualBasic.FileIO;


 class Program
{
    static void Main(string[] args)
    {
        List<Student> students = ReadStudentsFromCsv("students.csv");

        // 1. Найдем студента с именем Arseniy или последнего студента
        Student arsStudent = students.FirstOrDefault(s => s.Name == "Arseniy") ?? students.Last();
        Console.WriteLine($"1. Информация о студенте: {arsStudent.Name}, {arsStudent.Group}, {arsStudent.Mark}, {arsStudent.Subject}");

        // 2. Сгруппируем студентов по группам и выведем все группы поочередно
        var groups = students.GroupBy(s => s.Group);
        Console.WriteLine("2. Группы студентов:");
        foreach (var group in groups)
        {
            Console.WriteLine($"В группе {group.Key} учатся студенты: {string.Join(", ", group.Select(s => s.Name))}");
        }

        // 3. Сгруппируем студентов по предметам и найдем предмет с наибольшим количеством низких оценок (меньше 4)
        var subjects = students.GroupBy(s => s.Subject);
        var worstSubject = subjects.OrderByDescending(g => g.Count(s => s.Mark < 4)).First();
        Console.WriteLine($"3. Предмет с наибольшим количеством низких оценок: {worstSubject.Key}");

        // 4. Пересортируем студентов по имени в алфавитном порядке и наоборот
        List<Student> sortedByNameAsc = students.OrderBy(s => s.Name).ToList();
        List<Student> sortedByNameDesc = students.OrderByDescending(s => s.Name).ToList();

        // 5. Пересортируем студентов по оценкам и заменим группу на 1 для оценок 8 и выше
        students = students.OrderBy(s => s.Mark).ToList();
        foreach (var student in students)
        {
            if (student.Mark >= 8)
            {
                student.Group = "1";
            }
        }
        students = students.OrderBy(s => s.Group).ToList();

        // 6. Создадим копию списка студентов и заменим имена на перевернутые и рандомные оценки
        Random random = new Random();
        List<Student> copyStudents = students.Select(s => new Student
        {
            Name = new string(s.Name.Reverse().ToArray()),
            Group = s.Group,
            Mark = random.Next(1, 11),
            Subject = s.Subject
        }).ToList();

        // 7. Соединим два списка с условием, что в первом списке оценка больше 5
        var joinedStudents = students.Where(s => s.Mark > 5).Union(copyStudents).ToList();

        // 8. Сгруппируем по оценкам и предметам
        var groupedByMarkAndSubject = joinedStudents.GroupBy(s => new { s.Mark, s.Subject });
        Console.WriteLine("8. Группировка по оценкам и предметам:");
        foreach (var group in groupedByMarkAndSubject)
        {
            Console.WriteLine($"Оценка: {group.Key.Mark}, Предмет: {group.Key.Subject}");
            foreach (var student in group)
            {
                Console.WriteLine($"Студент: {student.Name}");
            }
        }
    }

    static List<Student> ReadStudentsFromCsv(string filePath)
    {
        List<Student> students = new List<Student>();

        using (TextFieldParser parser = new TextFieldParser(filePath))
        {
            parser.TextFieldType = FieldType.Delimited;
            parser.SetDelimiters(",");
            bool isFirstLine = true;

            while (!parser.EndOfData)
            {
                string[] fields = parser.ReadFields();

                if (isFirstLine)
                {
                    isFirstLine = false;
                    continue; // Пропускаем первую строку с заголовками столбцов
                }

                Student student = new Student
                {
                    Name = fields[0],
                    Group = fields[1],
                    Mark = int.Parse(fields[2]),
                    Subject = fields[3]
                };

                students.Add(student);
            }
        }

        return students;
    }
}

public class Student
{
    public string Name { get; set; }
    public string Group { get; set; }
    public int Mark { get; set; }
    public string Subject { get; set; }
}