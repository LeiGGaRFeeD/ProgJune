﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Задание 1: Фильтрация и сортировка коллекции объектов
        List<Student> students = GetStudents();
        var filteredStudents = students
            .Where(s => s.Subject == "Математика" && s.AverageGrade > 4.0)
            .OrderBy(s => s.LastName)
            .Select(s => new { s.LastName, s.FirstName });

        Console.WriteLine("Студенты, изучающие математику и имеющие средний балл выше 4.0, отсортированные по фамилии:");
        foreach (var student in filteredStudents)
        {
            Console.WriteLine($"{student.LastName} {student.FirstName}");
        }

        Console.WriteLine();

        // Задание 2: Группировка суммы заказов по клиентам
        List<Order> orders = GetOrders();
        var totalOrderAmounts = orders
            .GroupBy(o => o.CustomerId)
            .Select(group => new { CustomerId = group.Key, TotalAmount = group.Sum(o => o.TotalAmount) })
            .OrderByDescending(result => result.TotalAmount);

        Console.WriteLine("Общая сумма заказов по каждому клиенту, отсортированная по убыванию суммы:");
        foreach (var result in totalOrderAmounts)
        {
            Console.WriteLine($"Клиент {result.CustomerId}: {result.TotalAmount}");
        }

        Console.WriteLine();

        // Задание 3: Выделение уникальных элементов и последующая конкатенация
        List<string> collection1 = new List<string> { "apple", "banana", "orange", "banana", "grape" };
        List<string> collection2 = new List<string> { "banana", "grape", "kiwi", "pineapple" };

        var mergedUniqueSorted = collection1.Union(collection2)
            .OrderBy(s => s.Length)
            .ThenBy(s => s);

        Console.WriteLine("Уникальные элементы из двух коллекций, отсортированные по длине и алфавиту:");
        foreach (var item in mergedUniqueSorted)
        {
            Console.WriteLine(item);
        }

        Console.WriteLine();

        // Задание 4: Поиск первого и последнего элемента в выборке
        List<Student> allStudents = GetStudents();
        var students2023 = allStudents.Where(s => s.JoinDate.Year == 2023);
        var firstStudent = students2023.First();
        var lastStudent = students2023.Last();

        Console.WriteLine($"Первый студент, поступивший в 2023 году: {firstStudent.FirstName} {firstStudent.LastName}");
        Console.WriteLine($"Последний студент, поступивший в 2023 году: {lastStudent.FirstName} {lastStudent.LastName}");
    }

    // Модель студента
    class Student
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Subject { get; set; }
        public double AverageGrade { get; set; }
        public DateTime JoinDate { get; set; }
    }

    // Модель заказа
    class Order
    {
        public int CustomerId { get; set; }
        public double TotalAmount { get; set; }
    }

    // Получение списка студентов (замените этот метод на свой источник данных)
    static List<Student> GetStudents()
    {
        return new List<Student>
        {
            new Student { Id = 1, FirstName = "Иван", LastName = "Иванов", Subject = "Математика", AverageGrade = 4.5, JoinDate = new DateTime(2022, 9, 1) },
            new Student { Id = 2, FirstName = "Петр", LastName = "Петров", Subject = "Математика", AverageGrade = 3.8, JoinDate = new DateTime(2023, 2, 15) },
            new Student { Id = 3, FirstName = "Анна", LastName = "Сидорова", Subject = "Физика", AverageGrade = 4.2, JoinDate = new DateTime(2023, 5, 10) },
            new Student { Id = 4, FirstName = "Елена", LastName = "Павлова", Subject = "Математика", AverageGrade = 4.8, JoinDate = new DateTime(2023, 7, 20) }
        };
    }

    // Получение списка заказов (замените этот метод на свой источник данных)
    static List<Order> GetOrders()
    {
        return new List<Order>
        {
            new Order { CustomerId = 1, TotalAmount = 100.0 },
            new Order { CustomerId = 2, TotalAmount = 250.0 },
            new Order { CustomerId = 1, TotalAmount = 150.0 },
            new Order { CustomerId = 3, TotalAmount = 300.0 },
            new Order { CustomerId = 2, TotalAmount = 200.0 },
            new Order { CustomerId = 3, TotalAmount = 100.0 }
        };
    }
}
