﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Создаем массив чисел
        int[] numbers = { 1, 2, 3, 2, 4, 5, 6, 6, 7, 3 };

        // Берем первые 5 элементов
        int[] firstFiveElements = numbers.Take(5).ToArray();

        // Берем первые 5 элементов из перевёрнутого массива
        int[] reversedArray = numbers.Reverse().ToArray();
        int[] firstFiveReversedElements = reversedArray.Take(5).ToArray();

        // Объединяем оба массива
        int[] resultArray = firstFiveElements.Concat(firstFiveReversedElements).ToArray();

        // Выводим результат
        Console.WriteLine("Итоговый массив:");
        foreach (int num in resultArray)
        {
            Console.Write(num + " ");
        }
    }
}
