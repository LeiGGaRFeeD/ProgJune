﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Создаем строковый массив
        string[] words = { "I", " love ", "C#" };

        // Объединяем все элементы массива в одну строку
        string combinedString = string.Concat(words);

        // Выводим строку в консоль
        Console.WriteLine(combinedString);
    }
}
