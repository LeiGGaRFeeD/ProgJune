﻿using System;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        // Создаем первый строковый массив
        string[] array1 = { "hello", "hi", "good evening", "good day", "whatsup", "good morning", "goodbye" };

        // Создаем второй строковый массив
        string[] array2 = { "whatsup", "how are you", "hello", "bye", "hi" };

        // Обрабатываем массивы и объединяем их без повторений
        var result = array1.Skip(2).Take(3)
                           .Concat(array2.Take(3))
                           .Distinct();

        // Выводим все элементы получившейся последовательности
        Console.WriteLine("Результирующий массив:");
        result.ToList().ForEach(Console.WriteLine);
    }
}
